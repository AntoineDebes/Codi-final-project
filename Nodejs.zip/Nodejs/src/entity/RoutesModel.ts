export interface RouteModelServer {
  method: string;
  route: string;
  middleware: any;
  controller: any;
  action: string;
}
