export interface ProductModel {
  name: string;
  serialNumber: string;
  price: number;
  quantity: number;
  packaging: number;
  transport: number;
}
