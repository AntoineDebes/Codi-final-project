export interface CartModel {
  status: string | number;
}
